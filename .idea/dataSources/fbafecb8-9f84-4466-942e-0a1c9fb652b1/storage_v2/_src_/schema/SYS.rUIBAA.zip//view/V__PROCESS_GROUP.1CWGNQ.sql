create view V_$PROCESS_GROUP as
select "INDX","NAME","PID" from v$process_group
/

