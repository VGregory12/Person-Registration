create view V_$LATCHHOLDER as
select "PID","SID","LADDR","NAME","GETS" from v$latchholder
/

