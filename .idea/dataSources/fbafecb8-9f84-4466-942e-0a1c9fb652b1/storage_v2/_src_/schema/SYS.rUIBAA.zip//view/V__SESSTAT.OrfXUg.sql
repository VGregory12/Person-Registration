create view V_$SESSTAT as
select "SID","STATISTIC#","VALUE" from v$sesstat
/

