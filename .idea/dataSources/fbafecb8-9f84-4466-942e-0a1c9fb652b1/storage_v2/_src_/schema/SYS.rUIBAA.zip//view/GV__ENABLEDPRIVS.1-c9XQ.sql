create view GV_$ENABLEDPRIVS as
select "INST_ID","PRIV_NUMBER" from gv$enabledprivs
/

