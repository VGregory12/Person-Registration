create view GV_$SGAINFO as
select "INST_ID","NAME","BYTES","RESIZEABLE" from gv$sgainfo
/

