create view V_$ARCHIVE_GAP as
select "THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#" from v$archive_gap
/

