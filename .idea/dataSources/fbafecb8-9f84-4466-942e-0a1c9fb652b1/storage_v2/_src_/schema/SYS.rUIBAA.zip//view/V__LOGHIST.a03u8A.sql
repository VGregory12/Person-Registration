create view V_$LOGHIST as
select "THREAD#","SEQUENCE#","FIRST_CHANGE#","FIRST_TIME","SWITCH_CHANGE#" from v$loghist
/

