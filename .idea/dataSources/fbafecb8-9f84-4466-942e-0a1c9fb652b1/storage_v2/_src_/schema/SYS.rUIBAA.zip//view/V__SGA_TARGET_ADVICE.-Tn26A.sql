create view V_$SGA_TARGET_ADVICE as
select "SGA_SIZE","SGA_SIZE_FACTOR","ESTD_DB_TIME","ESTD_DB_TIME_FACTOR","ESTD_PHYSICAL_READS" from v$sga_target_advice
/

