create view V_$GC_ELEMENTS_W_COLLISIONS as
select "GC_ELEMENT_ADDR" from v$gc_elements_with_collisions
/

