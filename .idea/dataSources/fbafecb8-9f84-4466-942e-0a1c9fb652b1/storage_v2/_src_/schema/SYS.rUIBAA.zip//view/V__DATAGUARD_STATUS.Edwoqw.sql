create view V_$DATAGUARD_STATUS as
select "FACILITY","SEVERITY","DEST_ID","MESSAGE_NUM","ERROR_CODE","CALLOUT","TIMESTAMP","MESSAGE" from v$dataguard_status
/

