create view V_$CLUSTER_INTERCONNECTS as
select "NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from v$cluster_interconnects
/

