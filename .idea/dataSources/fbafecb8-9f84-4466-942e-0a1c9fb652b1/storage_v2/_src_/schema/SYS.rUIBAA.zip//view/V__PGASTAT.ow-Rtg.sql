create view V_$PGASTAT as
select "NAME","VALUE","UNIT" from v$pgastat
/

