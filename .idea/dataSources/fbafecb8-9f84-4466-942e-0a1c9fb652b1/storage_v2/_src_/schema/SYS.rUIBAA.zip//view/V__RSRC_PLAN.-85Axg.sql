create view V_$RSRC_PLAN as
select "ID","NAME","IS_TOP_PLAN","CPU_MANAGED" from v$rsrc_plan
/

