create view V_$QUEUEING_MTH as
select "NAME" from v$queueing_mth
/

