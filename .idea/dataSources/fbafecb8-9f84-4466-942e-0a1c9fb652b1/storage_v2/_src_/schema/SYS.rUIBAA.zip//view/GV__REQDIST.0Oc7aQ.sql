create view GV_$REQDIST as
select "INST_ID","BUCKET","COUNT" from gv$reqdist
/

