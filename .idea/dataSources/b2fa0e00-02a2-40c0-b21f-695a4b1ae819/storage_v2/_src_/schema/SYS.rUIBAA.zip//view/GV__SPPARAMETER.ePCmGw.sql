create view GV_$SPPARAMETER as
select "INST_ID","SID","NAME","TYPE","VALUE","DISPLAY_VALUE","ISSPECIFIED","ORDINAL","UPDATE_COMMENT" from gv$spparameter
/

