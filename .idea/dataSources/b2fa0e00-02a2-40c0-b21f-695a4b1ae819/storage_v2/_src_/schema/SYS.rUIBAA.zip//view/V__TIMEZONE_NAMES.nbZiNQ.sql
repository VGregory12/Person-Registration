create view V_$TIMEZONE_NAMES as
select "TZNAME","TZABBREV" from v$timezone_names
/

