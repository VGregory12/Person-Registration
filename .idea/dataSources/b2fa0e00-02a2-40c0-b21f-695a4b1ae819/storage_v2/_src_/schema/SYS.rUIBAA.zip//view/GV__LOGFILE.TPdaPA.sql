create view GV_$LOGFILE as
select "INST_ID","GROUP#","STATUS","TYPE","MEMBER","IS_RECOVERY_DEST_FILE" from gv$logfile
/

