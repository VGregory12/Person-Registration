create view V_$SUBCACHE as
select "OWNER_NAME","NAME","TYPE","HEAP_NUM","CACHE_ID","CACHE_CNT","HEAP_SZ","HEAP_ALOC","HEAP_USED" from v$subcache
/

