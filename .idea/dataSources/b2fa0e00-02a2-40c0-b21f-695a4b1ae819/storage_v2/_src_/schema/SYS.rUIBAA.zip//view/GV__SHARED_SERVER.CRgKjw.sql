create view GV_$SHARED_SERVER as
select "INST_ID","NAME","PADDR","STATUS","MESSAGES","BYTES","BREAKS","CIRCUIT","IDLE","BUSY","IN_NET","OUT_NET","REQUESTS" from gv$shared_server
/

