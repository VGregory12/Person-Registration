create view V_$SES_OPTIMIZER_ENV as
select "SID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE" from v$ses_optimizer_env
/

