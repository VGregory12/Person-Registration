create view V_$ROWCACHE_SUBORDINATE as
select "INDX","HASH","ADDRESS","CACHE#","SUBCACHE#","SUBCACHE_NAME","EXISTENT","PARENT","KEY" from v$rowcache_subordinate
/

