create view GV_$CONFIGURED_INTERCONNECTS as
select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$configured_interconnects
/

