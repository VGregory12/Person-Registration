create view GV_$LATCHNAME as
select "INST_ID","LATCH#","NAME","HASH" from gv$latchname
/

