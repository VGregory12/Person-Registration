create view V_$TIMEZONE_FILE as
select "FILENAME","VERSION" from v$timezone_file
/

