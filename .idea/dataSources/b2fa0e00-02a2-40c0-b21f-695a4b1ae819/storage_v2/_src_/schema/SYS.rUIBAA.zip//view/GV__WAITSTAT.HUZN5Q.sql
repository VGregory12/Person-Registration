create view GV_$WAITSTAT as
select "INST_ID","CLASS","COUNT","TIME" from gv$waitstat
/

