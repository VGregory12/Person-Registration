create view GV_$ENCRYPTED_TABLESPACES as
select "INST_ID","TS#","ENCRYPTIONALG","ENCRYPTEDTS" from gv$encrypted_tablespaces
/

