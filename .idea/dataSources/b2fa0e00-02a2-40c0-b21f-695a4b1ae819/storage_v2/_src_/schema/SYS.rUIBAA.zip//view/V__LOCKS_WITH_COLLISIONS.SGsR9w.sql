create view V_$LOCKS_WITH_COLLISIONS as
select "LOCK_ELEMENT_ADDR" from v$locks_with_collisions
/

