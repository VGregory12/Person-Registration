create view V_$LOCK_TYPE as
select "TYPE","NAME","ID1_TAG","ID2_TAG","IS_USER","DESCRIPTION" from v$lock_type
/

