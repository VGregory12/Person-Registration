create view V_$SQLPA_METRIC as
select "METRIC_NAME" from v$sqlpa_metric
/

