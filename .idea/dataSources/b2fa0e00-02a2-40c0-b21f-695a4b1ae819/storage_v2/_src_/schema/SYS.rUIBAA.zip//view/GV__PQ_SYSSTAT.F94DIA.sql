create view GV_$PQ_SYSSTAT as
select "INST_ID","STATISTIC","VALUE" from gv$pq_sysstat
/

