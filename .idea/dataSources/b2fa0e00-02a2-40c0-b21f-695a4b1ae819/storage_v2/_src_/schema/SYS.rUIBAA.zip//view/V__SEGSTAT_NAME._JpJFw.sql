create view V_$SEGSTAT_NAME as
select "STATISTIC#","NAME","SAMPLED" from v$segstat_name
/

