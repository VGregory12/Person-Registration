create view GV_$LATCHHOLDER as
select "INST_ID","PID","SID","LADDR","NAME","GETS" from gv$latchholder
/

